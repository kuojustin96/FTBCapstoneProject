﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ImpactShaderScript : MonoBehaviour {

    public float EffectTime;
    private Renderer rend;

	// Use this for initialization
	void Start () {
        rend = GetComponent<Renderer>();
	}

    void Update()
    {
        if (EffectTime > 0)
        {
            if (EffectTime < 450 && EffectTime > 400)
            {
                rend.sharedMaterial.SetVector("_ShieldColor", new Vector4(0.7f, 1f, 1f, 0f));
            }

            EffectTime -= Time.deltaTime * 1000;

            rend.sharedMaterial.SetFloat("_EffectTime", EffectTime);
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        Debug.Log("DSA");
        foreach (ContactPoint contact in collision.contacts)
        {
                
            rend.sharedMaterial.SetVector("_ShieldColor", new Vector4(0.7f, 1f, 1f, 0.05f));

            rend.sharedMaterial.SetVector("_Position", transform.InverseTransformPoint(contact.point));

            EffectTime = 500;
        }
    }
}
