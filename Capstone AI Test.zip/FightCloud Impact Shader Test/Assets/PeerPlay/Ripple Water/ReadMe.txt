Thank you for using Ripple Water Shader by PeerPlay!

This shader is free of use in free/commercial projects.

INSTRUCTIONS:
-Simply apply the shader to the plane, and add the collision script to the plane.
-If you want objects to be triggers, change the C# script to OnTriggerEnter
-To change the constant waves, look inside the shader, and read the comments written in there.
-There is a problem with scaling the dimentions differently of the plane, so keep the plane in its same dimensions when scaling.

If you like this shader please rate it, or leave a comment at the asset store.
I would love to hear your feedback!

If you have any questions, email me at: info@peerplay.nl
For Games and Tutorials by Peerplay check out the website: www.peerplay.nl
