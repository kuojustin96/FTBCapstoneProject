﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor (typeof(AIFieldOfView))]
public class FieldOfViewEditor : Editor {

	void OnSceneGUI()
    {
        AIFieldOfView aiFOW = (AIFieldOfView)target;
        Handles.color = Color.white;
        Handles.DrawWireArc(aiFOW.transform.position, Vector3.up, Vector3.forward, 360, aiFOW.viewRadius);
        Vector3 viewAngleA = aiFOW.DirFromAngle(-aiFOW.viewAngle / 2, false);
        Vector3 viewAngleB = aiFOW.DirFromAngle(aiFOW.viewAngle / 2, false);

        Handles.DrawLine(aiFOW.transform.position, aiFOW.transform.position + viewAngleA * aiFOW.viewRadius);
        Handles.DrawLine(aiFOW.transform.position, aiFOW.transform.position + viewAngleB * aiFOW.viewRadius);

        Handles.color = Color.red;
        foreach(Transform visibleTarget in aiFOW.visibleTargets)
        {
            Handles.DrawLine(aiFOW.transform.position, visibleTarget.position);
        }
    }
}
