﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoundUIController : MonoBehaviour {

    public static RoundUIController instance = null;

    private List<PlayerRoundData> playerRoundDataList = new List<PlayerRoundData>();

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }

    // Use this for initialization
    void Start() {

    }

    // Update is called once per frame
    void Update() {

    }

    public void EnableUI(int playerNum)
    {
        Debug.Log("UI Enabled");
    }

    private struct PlayerRoundData {
        public int playerNum;
        public int oldScore;
        public int newScore;
    }

    public void SetPlayerRoundData(int playerNum, int oldScore, int newScore)
    {
        PlayerRoundData prd = new PlayerRoundData();
        prd.playerNum = playerNum;
        prd.oldScore = oldScore;
        prd.newScore = newScore;
        playerRoundDataList.Add(prd);
    }
}
