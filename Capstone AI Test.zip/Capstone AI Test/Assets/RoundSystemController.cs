﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RoundSystemController : MonoBehaviour {

    public static RoundSystemController instance = null;

    [System.Serializable]
    public class playerScoreInfo
    {
        public string name;
        public GameObject playerGameObject;
        public int prevScore = 0;
        public int currentScore = 0;
    }

    public playerScoreInfo[] PlayerScoreData;

    private List<int> playersWhoScored = new List<int>();

    void Awake()
    {
        if(instance == null)
        {
            instance = this;
        } else
        {
            Destroy(this.gameObject);
        }
    }

	// Use this for initialization
	void Start () {
        DontDestroyOnLoad(this.gameObject);
	}

    void Update()
    {
    }

    public void AddScoreToPlayer(int amount, int playerNum)
    {
        if(!playersWhoScored.Contains(playerNum))
            playersWhoScored.Add(playerNum);

        PlayerScoreData[playerNum].currentScore += amount;
    }

    public void RoundOver(int playerNum)
    {
        if(playerNum < 0 || playerNum > PlayerScoreData.Length)
        {
            Debug.Log("Player number not in list");
            return;
        }

        //Player Number of the winner of the round
        RoundUIController.instance.EnableUI(playerNum);

        //Send updated score data to the UI script for each player that scored
        foreach (int x in playersWhoScored)
        {
            RoundUIController.instance.SetPlayerRoundData(x, PlayerScoreData[x].prevScore, PlayerScoreData[x].currentScore);
        }
    }
}
