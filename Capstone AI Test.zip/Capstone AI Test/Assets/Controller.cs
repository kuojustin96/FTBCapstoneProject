﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Controller : MonoBehaviour
{

    public List<Transform> locations = new List<Transform>();
    private AIScript ais;

    void Start()
    {
        ais = GetComponent<AIScript>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            int x = Random.Range(0, locations.Count);
            ais.ChangeState(AIStates.WalkingToLocation, locations[x]);
        }
    }
}