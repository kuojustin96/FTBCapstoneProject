﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public enum AIStates
{
    Sitting = 0,
    WalkingToLocation = 1,
    StandAtSpot = 2,
    Alerted = 3,
}

public class AIScript : MonoBehaviour {

    public Transform baseLocation;
    private AIFieldOfView aiFOW;
    private AIStates currentState;
    private NavMeshAgent agent;
    private Coroutine walkCo;
    private Transform walkLocation;
    private Transform lookTarget;

    private MeshRenderer aiFOWMeshRend;

	// Use this for initialization
	void Start () {
        aiFOW = GetComponent<AIFieldOfView>();
        agent = GetComponent<NavMeshAgent>();
        aiFOWMeshRend = aiFOW.viewMeshFilter.GetComponent<MeshRenderer>();

        transform.position = baseLocation.position;
        transform.LookAt(baseLocation.parent);
        ChangeState(AIStates.Sitting);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void ChangeState(AIStates newState, Transform location = null, Transform target = null)
    {
        currentState = newState;

        if(location != null)
            walkLocation = location;

        if (target != null)
            lookTarget = target;

        switch (newState)
        {
            case AIStates.Alerted:
                StartCoroutine(AlertedState());
                break;

            case AIStates.Sitting:
                SittingState();
                break;

            case AIStates.StandAtSpot:
                StartCoroutine(StandAtSpotState());
                break;

            case AIStates.WalkingToLocation:
                walkCo = StartCoroutine(WalkingToLocationState());
                break;
        }
    }

    private void SittingState()
    {
        if (walkLocation != null)
            transform.LookAt(walkLocation.parent);

        aiFOW.enabled = false;
        aiFOWMeshRend.enabled = false;
        aiFOW.visibleTargets.Clear();
    }

    private IEnumerator WalkingToLocationState()
    {
        if(walkLocation == null)
        {
            Debug.Log("Walk location not set");
            StopCoroutine(walkCo);
            walkCo = null;
        }
        aiFOW.enabled = true;
        aiFOWMeshRend.enabled = true;
        agent.destination = walkLocation.position;

        float dist = Vector3.Distance(agent.transform.position, walkLocation.position);

        while (dist > 0.1f)
        {
            dist = Vector3.Distance(agent.transform.position, walkLocation.position);
            yield return null;
        }

        transform.LookAt(walkLocation.parent);

        if (walkLocation == baseLocation)
            ChangeState(AIStates.Sitting);
        else
            ChangeState(AIStates.StandAtSpot);
    }

    private IEnumerator StandAtSpotState()
    {
        Debug.Log("Reached destination");
        aiFOW.enabled = false;
        aiFOWMeshRend.enabled = false;
        yield return new WaitForSeconds(3f);
        aiFOW.visibleTargets.Clear();
        ChangeState(AIStates.WalkingToLocation, baseLocation);
    }

    private IEnumerator AlertedState()
    {
        StopCoroutine(walkCo);
        agent.destination = transform.position;
        transform.LookAt(lookTarget);
        Debug.Log("Caught a player!");
        yield return new WaitForSeconds(3f);
        if (walkLocation == baseLocation)
            ChangeState(AIStates.WalkingToLocation, baseLocation);
        else
            ChangeState(AIStates.WalkingToLocation, walkLocation);
    }
}
